import React, { useEffect, useState, useRef } from 'react';
import { api } from '../api.js';
import { useI18n } from '../i18n/I18nContext.jsx';

const empty = {
  employee_id: '', full_name: '', email: '', job_title: '', manager_id: '',
  routing_code: '', iban: '', fixed_income: 0, variable_income: 0,
  annual_leave_balance: 30, active: true
};

export default function Employees() {
  const { t } = useI18n();
  const [list, setList] = useState([]);
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);
  const [msg, setMsg] = useState(null);
  const [err, setErr] = useState(null);
  const fileRef = useRef();

  const load = () => api.listEmployees().then(d => setList(d.employees)).catch(e => setErr(e.message));
  useEffect(() => { load(); }, []);

  const save = async (form) => {
    setErr(null); setMsg(null);
    try {
      if (form.id) await api.updateEmployee(form.id, form);
      else await api.createEmployee(form);
      setEditing(null); setCreating(false);
      setMsg(t('emp.saved'));
      load();
    } catch (e) { setErr(e.message); }
  };

  const remove = async (emp) => {
    if (!confirm(t('emp.confirmDelete', { name: emp.full_name || emp.employee_id }))) return;
    try { await api.deleteEmployee(emp.id); load(); }
    catch (e) { setErr(e.message); }
  };

  const onImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErr(null); setMsg(null);
    try {
      const r = await api.importEmployees(file);
      const key = r.errors?.length ? 'emp.importSuccessWithErrors' : 'emp.importSuccess';
      setMsg(t(key, { inserted: r.inserted, updated: r.updated, errors: r.errors?.length || 0 }));
      load();
    } catch (e) { setErr(e.message); }
    finally { if (fileRef.current) fileRef.current.value = ''; }
  };

  return (
    <div>
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ margin: 0 }}>{t('emp.title')} ({list.length})</h2>
          <div className="btn-group">
            <input ref={fileRef} type="file" accept=".csv,.xlsx" style={{ display: 'none' }} onChange={onImport} />
            <button onClick={() => fileRef.current?.click()}>{t('emp.import')}</button>
            <button className="primary" onClick={() => { setCreating(true); setEditing({ ...empty }); }}>{t('emp.add')}</button>
          </div>
        </div>
        {msg && <div className="alert success" style={{ marginTop: 12 }}>{msg}</div>}
        {err && <div className="alert error" style={{ marginTop: 12 }}>{err}</div>}
        <div className="small" style={{ marginTop: 8 }}>
          {t('emp.importHint')} <code className="mono">employee_id, full_name, routing_code, iban, fixed_income, variable_income</code>
        </div>
      </div>

      {editing && (
        <EmployeeForm
          initial={editing}
          isNew={creating}
          employees={list}
          onCancel={() => { setEditing(null); setCreating(false); }}
          onSave={save}
        />
      )}

      <div className="card">
        <table>
          <thead>
            <tr>
              <th>{t('emp.colId')}</th>
              <th>{t('emp.colName')}</th>
              <th>{t('emp.colRouting')}</th>
              <th>{t('emp.colIban')}</th>
              <th className="right">{t('emp.colFixed')}</th>
              <th className="right">{t('emp.colVariable')}</th>
              <th>{t('emp.colActive')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {list.length === 0 && <tr><td colSpan={8} className="center" style={{ padding: 24, color: 'var(--muted)' }}>{t('emp.empty')}</td></tr>}
            {list.map(e => (
              <tr key={e.id}>
                <td className="mono">{e.employee_id}</td>
                <td>{e.full_name || '—'}</td>
                <td className="mono">{e.routing_code}</td>
                <td className="mono">{e.iban}</td>
                <td className="right">{Number(e.fixed_income).toLocaleString()}</td>
                <td className="right">{Number(e.variable_income).toLocaleString()}</td>
                <td>{e.active ? <span className="badge success">{t('common.active')}</span> : <span className="badge muted">{t('common.inactive')}</span>}</td>
                <td className="right">
                  <button onClick={() => { setCreating(false); setEditing(e); }}>{t('common.edit')}</button>{' '}
                  <button className="danger" onClick={() => remove(e)}>{t('common.delete')}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function EmployeeForm({ initial, isNew, onSave, onCancel, employees = [] }) {
  const { t } = useI18n();
  const [f, setF] = useState(initial);
  useEffect(() => { setF(initial); }, [initial]);
  const set = (k) => (e) => setF(x => ({ ...x, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const managerCandidates = employees.filter(emp => emp.id !== f.id && emp.active);

  return (
    <div className="card">
      <h3>{isNew ? t('emp.new') : t('emp.editing')}</h3>
      <div className="row">
        <div className="col"><label>{t('emp.fieldId')} *</label><input value={f.employee_id} onChange={set('employee_id')} /></div>
        <div className="col"><label>{t('emp.fieldName')}</label><input value={f.full_name || ''} onChange={set('full_name')} /></div>
        <div className="col"><label>Email</label><input type="email" value={f.email || ''} onChange={set('email')} /></div>
        <div className="col"><label>Job title</label><input value={f.job_title || ''} onChange={set('job_title')} /></div>
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <div className="col"><label>{t('emp.fieldRouting')} *</label><input value={f.routing_code} onChange={set('routing_code')} /></div>
        <div className="col" style={{ flex: 2 }}><label>{t('emp.fieldIban')} *</label><input value={f.iban} onChange={set('iban')} placeholder="AE..." /></div>
        <div className="col">
          <label>Manager</label>
          <select value={f.manager_id || ''} onChange={set('manager_id')}>
            <option value="">{t('common.none')}</option>
            {managerCandidates.map(m => (
              <option key={m.id} value={m.id}>{m.full_name || m.employee_id}</option>
            ))}
          </select>
        </div>
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <div className="col"><label>{t('emp.fieldFixed')}</label><input type="number" step="0.01" value={f.fixed_income} onChange={set('fixed_income')} /></div>
        <div className="col"><label>{t('emp.fieldVariable')}</label><input type="number" step="0.01" value={f.variable_income} onChange={set('variable_income')} /></div>
        <div className="col"><label>{t('dash.myLeaveBalance')}</label><input type="number" step="0.5" value={f.annual_leave_balance ?? 30} onChange={set('annual_leave_balance')} /></div>
        <div className="col"><label>&nbsp;</label><label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="checkbox" checked={!!f.active} onChange={set('active')} style={{ width: 'auto' }} /> {t('common.active')}</label></div>
      </div>
      <div className="btn-group" style={{ marginTop: 16 }}>
        <button className="primary" onClick={() => onSave(f)}>{t('common.save')}</button>
        <button onClick={onCancel}>{t('common.cancel')}</button>
      </div>
    </div>
  );
}
